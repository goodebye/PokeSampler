#pragma once

#include "../JuceLibraryCode/JuceHeader.h"

/*
	This file defines our Synthesizer and SamplerVoices. These are used by our SamplerComponent et al.
	to make sounds based on MIDI messages.
*/

class SamplerAudioSource : public AudioSource
{
public:
	SamplerAudioSource()
	{
		for (auto i = 0; i < 4; ++i)
			// add voices to synth for polyphonic playback
			synth.addVoice(new SamplerVoice());
	}

	void setUsingSampleSound()
	{
		// loading sample
		WavAudioFormat wavFormat;
		InputStream* is = File::getSpecialLocation(File::currentExecutableFile).getChildFile("sample.wav").createInputStream();
		ScopedPointer<AudioFormatReader> audioReader(wavFormat.createReaderFor(is, true));

		// setting range of sample
		BigInteger allNotes;
		allNotes.setRange(0, 128, true);

		// adding the sample to the synthesizer
		synth.addSound(new SamplerSound(
			"example sound", *audioReader, allNotes, 74,  0.1, 0.1, 10.0
		));
	}

	void prepareToPlay(int /*samplesPerBlockExpected*/, double sampleRate) override
	{
		// setting playback rate for our synthesizer based on the call
		// in the MainComponent
		synth.setCurrentPlaybackSampleRate(sampleRate);
	}

	void releaseResources() override {}

	void getNextAudioBlock(const AudioSourceChannelInfo& bufferToFill) override
	{
		// fill our audio buffer with sound!
		MidiBuffer* midiBuff = new MidiBuffer();

		synth.renderNextBlock(*bufferToFill.buffer, *midiBuff, bufferToFill.startSample, bufferToFill.numSamples);
	}

	Synthesiser* getSynth() {
		// this method exists so we can have an outside reference to our synthesizer,
		// which allows us to send it messages from outside the SamplerComponent

		return &synth;
	}

private:
	Synthesiser synth;
};