#include "Pattern.h"

/*
	Patterns hold a vector of Steps, which themselves contain note data.
	Pattern is used by our sequencer to hold steps with notes
	to be given off to the sampler.
*/

int Pattern::getNumberOfSteps()
{
	return numberOfSteps;
}

std::vector<Step> Pattern::getSteps()
{
	return steps;
}

Step Pattern::getStep(int index) {
	return steps[index];
}

void Pattern::initializePattern()
{
	for (int n = 0; n < defaultNumberOfSteps; n++) {
		steps.push_back(Step());
	}
}
